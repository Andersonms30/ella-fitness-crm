import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Ella Fitness CRM",
  description: "Sistema de gestão para lojas fitness",
  viewport: "width=device-width, initial-scale=1, maximum-scale=1",
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body style={{margin:0, padding:0, background:"#07070f"}}>{children}</body>
    </html>
  );
}