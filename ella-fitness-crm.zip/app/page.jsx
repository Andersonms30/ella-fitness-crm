"use client";
// ============================================================
// FITNESS CRM — SaaS com Supabase Realtime
// Substitua as constantes abaixo com suas credenciais Supabase
// ============================================================
"use client";
import { useState, useEffect, useCallback, useRef } from "react";
import { createClient } from "@supabase/supabase-js";
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from "recharts";

// ── CONFIGURE AQUI ────────────────────────────────────────────
const SUPABASE_URL = "https://sxwjyvpqsprwthyqtjzy.supabase.co";
const SUPABASE_KEY = "sb_publishable_j6F1AdpN9B9OUNBUXoFmOA_R-Sjh_Wn";
// ─────────────────────────────────────────────────────────────

const sb = createClient(SUPABASE_URL, SUPABASE_KEY);

// ── Design Tokens ─────────────────────────────────────────────
const G = {
  bg:"#07070f", surf:"#0f0f1a", card:"#13131f", bord:"#ffffff0d", bord2:"#ffffff16",
  pink:"#f472b6", rose:"#fb7185", violet:"#a78bfa", purple:"#7c3aed",
  green:"#34d399", amber:"#fbbf24", red:"#f87171", sky:"#38bdf8",
  muted:"#ffffff38", sub:"#ffffff65", text:"#f5f5ff"
};
const PAL = [G.pink,G.violet,G.green,G.amber,G.rose,G.sky,"#fb923c","#a3e635"];
const METHODS = { pix:"PIX", debit:"Débito", credit:"Crédito", crediario:"Crediário" };
const MC = { pix:G.green, debit:G.amber, credit:G.violet, crediario:G.rose };

// ── Utils ─────────────────────────────────────────────────────
const R    = v => `R$ ${Number(v||0).toFixed(2).replace(".",",")}`;
const pct  = (a,b) => b ? ((a/b)*100).toFixed(1)+"%" : "—";
const TODAY= () => new Date().toISOString().slice(0,10);
const INI  = s => (s||"?").trim().split(/\s+/).map(w=>w[0]).join("").slice(0,2).toUpperCase();
const fmtD = d => d ? new Date(d+"T12:00:00").toLocaleDateString("pt-BR") : "—";
const fmtMonth = d => d ? new Date(d+"T12:00:00").toLocaleDateString("pt-BR",{month:"short",year:"numeric"}) : "";
const addMonths = (dateStr, n) => {
  const d = new Date(dateStr+"T12:00:00"); d.setMonth(d.getMonth()+n); return d.toISOString().slice(0,10);
};
const dueDateDay = (refDate, monthOffset, day) => {
  const d = new Date(refDate+"T12:00:00");
  d.setMonth(d.getMonth()+monthOffset);
  d.setDate(parseInt(day)||10);
  return d.toISOString().slice(0,10);
};

// ── Primitives ────────────────────────────────────────────────
const Card = ({children,style,onClick}) => (
  <div onClick={onClick} style={{background:G.card,border:`1px solid ${G.bord}`,borderRadius:14,padding:"16px 18px",...style,cursor:onClick?"pointer":undefined}}>{children}</div>
);
const Badge = ({children,color}) => {
  const c=color||G.pink;
  return <span style={{background:c+"1e",color:c,border:`1px solid ${c}30`,borderRadius:20,padding:"2px 10px",fontSize:11,fontWeight:700,whiteSpace:"nowrap"}}>{children}</span>;
};
const Btn = ({children,onClick,variant,small,full,disabled,style={}}) => {
  const bg = disabled?"#ffffff0e"
    : variant==="danger"  ? G.red
    : variant==="success" ? G.green
    : variant==="ghost"   ? "#ffffff0e"
    : variant==="amber"   ? `linear-gradient(135deg,${G.amber},#f59e0b)`
    : variant==="pink"    ? `linear-gradient(135deg,${G.pink},${G.rose})`
    : variant==="green"   ? `linear-gradient(135deg,${G.green},#059669)`
    : `linear-gradient(135deg,${G.violet},${G.purple})`;
  return (
    <button onClick={disabled?undefined:onClick} style={{
      background:bg, color:disabled?G.muted:"#fff", border:"none",
      borderRadius:9, padding:small?"5px 11px":"9px 18px",
      fontSize:small?12:14, fontWeight:700,
      cursor:disabled?"not-allowed":"pointer",
      width:full?"100%":undefined, flexShrink:0, ...style
    }}>{children}</button>
  );
};
const iS = {background:G.bg,color:G.text,border:`1px solid ${G.bord2}`,borderRadius:9,padding:"9px 12px",fontSize:14,outline:"none",width:"100%",boxSizing:"border-box"};
const Inp = ({label,hint,...p}) => (
  <div style={{display:"flex",flexDirection:"column",gap:4}}>
    {label && <span style={{color:G.muted,fontSize:11,textTransform:"uppercase",letterSpacing:.8}}>{label}</span>}
    <input {...p} style={{...iS,...p.style}}/>
    {hint && <span style={{color:G.muted,fontSize:11}}>{hint}</span>}
  </div>
);
const Sel = ({label,children,...p}) => (
  <div style={{display:"flex",flexDirection:"column",gap:4}}>
    {label && <span style={{color:G.muted,fontSize:11,textTransform:"uppercase",letterSpacing:.8}}>{label}</span>}
    <select {...p} style={{...iS,...p.style}}>{children}</select>
  </div>
);
const TA = ({label,...p}) => (
  <div style={{display:"flex",flexDirection:"column",gap:4}}>
    {label && <span style={{color:G.muted,fontSize:11,textTransform:"uppercase",letterSpacing:.8}}>{label}</span>}
    <textarea {...p} style={{...iS,resize:"vertical",minHeight:60,...p.style}}/>
  </div>
);
const Divider = ({my=12}) => <div style={{height:1,background:G.bord,margin:`${my}px 0`}}/>;
const Spin = () => (
  <div style={{display:"inline-block",width:16,height:16,border:`2px solid ${G.muted}`,borderTopColor:G.pink,borderRadius:"50%",animation:"spin 0.7s linear infinite"}}/>
);
function Toast({msg,color}){
  if(!msg)return null;
  return <div style={{position:"fixed",bottom:24,left:"50%",transform:"translateX(-50%)",background:color||G.violet,color:"#fff",padding:"10px 22px",borderRadius:10,fontWeight:700,fontSize:13,zIndex:3000,boxShadow:"0 4px 28px #0009",whiteSpace:"nowrap",pointerEvents:"none"}}>{msg}</div>;
}
function Modal({title,onClose,children,wide}){
  return(
    <div style={{position:"fixed",inset:0,background:"#000000dd",zIndex:1000,display:"flex",alignItems:"flex-start",justifyContent:"center",padding:16,overflowY:"auto"}} onClick={e=>{if(e.target===e.currentTarget)onClose();}}>
      <div style={{background:G.surf,border:`1px solid ${G.bord2}`,borderRadius:18,padding:22,width:"100%",maxWidth:wide?700:480,marginTop:24,marginBottom:24}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:18}}>
          <strong style={{fontSize:16}}>{title}</strong>
          <button onClick={onClose} style={{background:"none",border:"none",color:G.muted,fontSize:22,cursor:"pointer",lineHeight:1}}>✕</button>
        </div>
        {children}
      </div>
    </div>
  );
}
function PhotoUpload({value,onChange}){
  const ref=useRef();
  const handle=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=ev=>onChange(ev.target.result);r.readAsDataURL(f);};
  return(
    <div>
      <span style={{color:G.muted,fontSize:11,textTransform:"uppercase",letterSpacing:.8,display:"block",marginBottom:5}}>Foto</span>
      <div onClick={()=>ref.current.click()} style={{width:"100%",height:110,borderRadius:10,border:`2px dashed ${G.bord2}`,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",cursor:"pointer",overflow:"hidden",background:G.bg,position:"relative"}}>
        {value?<img src={value} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>:<><span style={{fontSize:24,marginBottom:4}}>📷</span><span style={{color:G.muted,fontSize:12}}>Adicionar foto</span></>}
        {value&&<div style={{position:"absolute",bottom:0,left:0,right:0,background:"#000a",textAlign:"center",fontSize:11,color:"#fff",padding:"3px 0"}}>Trocar</div>}
      </div>
      <input ref={ref} type="file" accept="image/*" onChange={handle} style={{display:"none"}}/>
    </div>
  );
}

// ── Realtime indicator ────────────────────────────────────────
function RTBadge({connected}){
  return(
    <div style={{display:"flex",alignItems:"center",gap:5,fontSize:11,color:connected?G.green:G.amber}}>
      <div style={{width:7,height:7,borderRadius:"50%",background:connected?G.green:G.amber,boxShadow:connected?`0 0 6px ${G.green}`:undefined}}/>
      {connected?"Ao vivo":"Reconectando..."}
    </div>
  );
}

// ── WA helper ─────────────────────────────────────────────────
function waLink(phone, custName, instN, val, dueDate, storeName, overdue){
  const clean = phone.replace(/\D/g,"");
  const first = (custName||"").split(" ")[0];
  const msg = overdue
    ? `Olá ${first}! 😊 Aqui é da ${storeName}. A parcela ${instN}/${" "} no valor de ${R(val)} venceu em ${fmtD(dueDate)}. Podemos resolver? 🙏`
    : `Olá ${first}! 😊 Aqui é da ${storeName}. Lembrete: parcela ${instN} de ${R(val)} vence em ${fmtD(dueDate)}. Qualquer dúvida fale com a gente! 💪`;
  return `https://wa.me/${clean}?text=${encodeURIComponent(msg)}`;
}

// ── Auth Screen ───────────────────────────────────────────────
function AuthScreen({onAuth}){
  const [mode,  setMode]  = useState("login");
  const [email, setEmail] = useState("");
  const [pass,  setPass]  = useState("");
  const [store, setStore] = useState("");
  const [err,   setErr]   = useState("");
  const [loading,setLoad] = useState(false);

  const submit = async () => {
    setErr(""); setLoad(true);
    try {
      if(mode==="login"){
        const {data,error} = await sb.auth.signInWithPassword({email,password:pass});
        if(error) throw error;
        onAuth(data.user);
      } else {
        if(!store.trim()) throw new Error("Nome da loja é obrigatório");
        const {data,error} = await sb.auth.signUp({email,password:pass});
        if(error) throw error;
        // Create store + link user
        const {data:storeData,error:sErr} = await sb.from("stores").insert({name:store,owner_email:email}).select().single();
        if(sErr) throw sErr;
        await sb.from("store_users").insert({store_id:storeData.id,user_id:data.user.id,role:"owner"});
        onAuth(data.user);
      }
    } catch(e){ setErr(e.message||"Erro desconhecido"); }
    setLoad(false);
  };

  return(
    <div style={{minHeight:"100vh",background:G.bg,display:"flex",alignItems:"center",justifyContent:"center",padding:16}}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <div style={{width:"100%",maxWidth:400}}>
        <div style={{textAlign:"center",marginBottom:32}}>
          <div style={{fontSize:44,marginBottom:8}}>👗</div>
          <div style={{fontSize:26,fontWeight:900,background:`linear-gradient(90deg,${G.pink},${G.violet})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>Fitness CRM</div>
          <div style={{color:G.muted,fontSize:13,marginTop:4}}>Sistema de gestão para lojas fitness</div>
        </div>
        <Card style={{display:"flex",flexDirection:"column",gap:14}}>
          <div style={{display:"flex",gap:0,background:G.bg,borderRadius:10,padding:3}}>
            {[["login","Entrar"],["register","Criar conta"]].map(([k,l])=>(
              <button key={k} onClick={()=>{setMode(k);setErr("");}} style={{flex:1,padding:"8px 0",borderRadius:8,border:"none",background:mode===k?`linear-gradient(135deg,${G.pink},${G.violet})`:"transparent",color:mode===k?"#fff":G.muted,fontWeight:mode===k?700:400,fontSize:13,cursor:"pointer"}}>{l}</button>
            ))}
          </div>
          {mode==="register" && <Inp label="Nome da loja" value={store} onChange={e=>setStore(e.target.value)} placeholder="Ex: FitStore Moda Fitness"/>}
          <Inp label="E-mail" type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="seu@email.com"/>
          <Inp label="Senha" type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder="••••••••" onKeyDown={e=>e.key==="Enter"&&submit()}/>
          {err && <div style={{color:G.red,fontSize:12,background:`${G.red}12`,borderRadius:8,padding:"8px 12px"}}>{err}</div>}
          <Btn full variant="pink" onClick={submit} disabled={loading} style={{padding:"12px 0",fontSize:15}}>
            {loading?<Spin/>:mode==="login"?"Entrar":"Criar conta"}
          </Btn>
        </Card>
        <div style={{textAlign:"center",color:G.muted,fontSize:11,marginTop:16}}>
          Dados armazenados com segurança via Supabase
        </div>
      </div>
    </div>
  );
}

// ── Period Picker ─────────────────────────────────────────────
function PeriodPicker({df,dt,setDf,setDt,preset,setPreset}){
  const apply = k => {
    setPreset(k);
    const now = new Date();
    if(k==="7d"){const d=new Date();d.setDate(now.getDate()-6);setDf(d.toISOString().slice(0,10));setDt(now.toISOString().slice(0,10));}
    else if(k==="30d"){const d=new Date();d.setDate(now.getDate()-29);setDf(d.toISOString().slice(0,10));setDt(now.toISOString().slice(0,10));}
    else if(k==="60d"){const d=new Date();d.setDate(now.getDate()-59);setDf(d.toISOString().slice(0,10));setDt(now.toISOString().slice(0,10));}
    else if(k==="mes"){const d=new Date(now.getFullYear(),now.getMonth(),1);setDf(d.toISOString().slice(0,10));setDt(now.toISOString().slice(0,10));}
  };
  return(
    <div style={{display:"flex",flexDirection:"column",gap:8}}>
      <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
        {[["7d","7 dias"],["30d","30 dias"],["60d","60 dias"],["mes","Este mês"],["custom","Período"]].map(([k,l])=>(
          <button key={k} onClick={()=>apply(k)} style={{padding:"5px 12px",borderRadius:20,border:"none",fontSize:12,fontWeight:preset===k?700:400,background:preset===k?G.pink:"#ffffff0e",color:preset===k?"#fff":G.muted,cursor:"pointer"}}>{l}</button>
        ))}
      </div>
      {preset==="custom"&&(
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
          <Inp label="De" type="date" value={df} onChange={e=>setDf(e.target.value)}/>
          <Inp label="Até" type="date" value={dt} onChange={e=>setDt(e.target.value)}/>
        </div>
      )}
    </div>
  );
}

// ── InstallmentRow ────────────────────────────────────────────
function InstRow({inst,custName,custPhone,onPay,storeName,showWA=true}){
  const overdue = !inst.paid && inst.due_date < TODAY();
  const dueToday= !inst.paid && inst.due_date === TODAY();
  const col = inst.paid?G.green:overdue?G.red:dueToday?G.amber:G.muted+"88";
  return(
    <div style={{display:"flex",alignItems:"center",gap:9,background:inst.paid?"#34d39910":overdue?"#f8717110":dueToday?"#fbbf2410":"#ffffff07",border:`1px solid ${inst.paid?G.green+"30":overdue?G.red+"30":dueToday?G.amber+"30":G.bord}`,borderRadius:9,padding:"9px 12px"}}>
      <div style={{width:24,height:24,borderRadius:"50%",flexShrink:0,background:col,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:"#fff"}}>{inst.number}</div>
      <div style={{flex:1}}>
        <div style={{fontSize:13,fontWeight:700,color:inst.paid?G.green:overdue?G.red:G.text}}>{R(inst.amount)}</div>
        <div style={{fontSize:11,color:G.muted}}>Venc: {fmtD(inst.due_date)}{inst.paid_at?` · Pago em ${fmtD(inst.paid_at.slice(0,10))}`:"" }</div>
      </div>
      <Badge color={inst.paid?G.green:overdue?G.red:dueToday?G.amber:G.violet}>{inst.paid?"Pago":overdue?"Vencida":dueToday?"Hoje":"Pendente"}</Badge>
      {!inst.paid && onPay && <Btn small variant="success" onClick={()=>onPay(inst.id)}>✓</Btn>}
      {!inst.paid && showWA && custPhone && (
        <button onClick={()=>window.open(waLink(custPhone,custName,inst.number,inst.amount,inst.due_date,storeName,overdue),"_blank")}
          style={{background:"#25D36618",border:"1px solid #25D36640",color:"#25D366",borderRadius:7,padding:"4px 9px",fontSize:13,cursor:"pointer",fontWeight:700,flexShrink:0}}>📱</button>
      )}
    </div>
  );
}

// ── Dashboard ─────────────────────────────────────────────────
function Dashboard({sales,products,customers,costs,installments}){
  const [preset,setPreset]=useState("30d");
  const [df,setDf]=useState(()=>{const d=new Date();d.setDate(d.getDate()-29);return d.toISOString().slice(0,10);});
  const [dt,setDt]=useState(TODAY);

  const fSales = sales.filter(s=>s.date>=df&&s.date<=dt);
  const totalRev  = fSales.reduce((a,s)=>a+Number(s.total),0);
  const totalCogs = fSales.reduce((a,s)=>a+s.items.reduce((b,i)=>b+Number(i.cost_price)*i.quantity,0),0);

  // Costs in period
  const fixedCosts  = costs.filter(c=>c.type==="fixed"&&(!c.ref_month||(c.ref_month>=df.slice(0,7)&&c.ref_month<=dt.slice(0,7)))).reduce((a,c)=>a+Number(c.amount),0);
  const varCosts    = costs.filter(c=>c.type==="variable"&&c.created_at.slice(0,10)>=df&&c.created_at.slice(0,10)<=dt).reduce((a,c)=>a+Number(c.amount),0);
  const totalCosts  = totalCogs + fixedCosts + varCosts;
  const grossMargin = totalRev - totalCogs;
  const netProfit   = totalRev - totalCosts;
  const marginPct   = totalRev ? ((grossMargin/totalRev)*100).toFixed(1) : 0;

  const pendingAll  = installments.filter(i=>!i.paid).reduce((a,i)=>a+Number(i.amount),0);
  const overdueAll  = installments.filter(i=>!i.paid&&i.due_date<TODAY()).reduce((a,i)=>a+Number(i.amount),0);

  // Chart
  const days = Math.min(60,Math.ceil((new Date(dt)-new Date(df))/(86400000))+1);
  const chartData = Array.from({length:days},(_,i)=>{
    const d=new Date(df+"T12:00:00");d.setDate(d.getDate()+i);
    const ds=d.toISOString().slice(0,10);
    const dayS=fSales.filter(s=>s.date===ds);
    return {day:d.toLocaleDateString("pt-BR",{day:"2-digit",month:"2-digit"}),receita:+dayS.reduce((a,s)=>a+Number(s.total),0).toFixed(2),custo:+dayS.reduce((a,s)=>a+s.items.reduce((b,it)=>b+Number(it.cost_price)*it.quantity,0),0).toFixed(2)};
  });

  const catMap={};fSales.forEach(s=>s.items.forEach(it=>{catMap[it.category||"Geral"]=(catMap[it.category||"Geral"]||0)+Number(it.unit_price)*it.quantity;}));
  const pie=Object.entries(catMap).map(([name,value])=>({name,value:+value.toFixed(2)}));
  const mMap={pix:0,debit:0,credit:0,crediario:0};fSales.forEach(s=>{mMap[s.method]=(mMap[s.method]||0)+Number(s.total);});
  const topC=customers.map(c=>{const cs=fSales.filter(s=>s.customer_id===c.id);return{...c,spent:cs.reduce((a,s)=>a+Number(s.total),0),n:cs.length};}).sort((a,b)=>b.spent-a.spent).slice(0,4);
  const lowStock=products.filter(p=>p.active&&p.stock<=3);

  return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      <Card style={{padding:"12px 16px"}}><PeriodPicker df={df} dt={dt} setDf={setDf} setDt={setDt} preset={preset} setPreset={setPreset}/></Card>

      {/* KPIs financeiros */}
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))",gap:10}}>
        {[
          ["Faturamento",R(totalRev),G.pink,"💰"],
          ["Margem bruta",R(grossMargin)+" ("+marginPct+"%)",G.violet,"📊"],
          ["Custos totais",R(totalCosts),G.amber,"💸"],
          ["Lucro líquido",R(netProfit),netProfit>=0?G.green:G.red,"🏆"],
          ["A receber",R(pendingAll),G.sky,"🕐"],
          ["Vencidos",R(overdueAll),G.red,"⚠️"],
        ].map(([l,v,col,ic])=>(
          <Card key={l} style={{borderLeft:`3px solid ${col}`,padding:"13px 14px"}}>
            <div style={{fontSize:14,marginBottom:4}}>{ic}</div>
            <div style={{color:G.muted,fontSize:10,textTransform:"uppercase",letterSpacing:.8}}>{l}</div>
            <div style={{color:col,fontSize:17,fontWeight:900,marginTop:4,wordBreak:"break-all"}}>{v}</div>
          </Card>
        ))}
      </div>

      {/* Custos breakdown */}
      <Card>
        <div style={{fontWeight:700,fontSize:14,marginBottom:10}}>💸 Composição de custos</div>
        <div style={{display:"flex",flexDirection:"column",gap:8}}>
          {[["CMV (custo de mercadoria)",totalCogs,G.rose],["Custos fixos",fixedCosts,G.amber],["Custos variáveis",varCosts,G.violet]].map(([l,v,col])=>(
            <div key={l} style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div style={{flex:1}}>
                <div style={{fontSize:13}}>{l}</div>
                <div style={{height:3,background:G.bord,borderRadius:3,marginTop:4,overflow:"hidden"}}>
                  <div style={{height:"100%",borderRadius:3,background:col,width:`${totalCosts?Math.min(100,(v/totalCosts)*100):0}%`,transition:"width .4s"}}/>
                </div>
              </div>
              <div style={{color:col,fontWeight:700,fontSize:14,minWidth:80,textAlign:"right"}}>{R(v)}</div>
            </div>
          ))}
        </div>
      </Card>

      {lowStock.length>0&&<Card style={{borderColor:G.red+"44",background:`${G.red}08`}}><div style={{color:G.red,fontWeight:700,marginBottom:7,fontSize:13}}>⚠️ Estoque baixo</div><div style={{display:"flex",flexWrap:"wrap",gap:6}}>{lowStock.map(p=><Badge key={p.id} color={G.red}>{p.name} — {p.stock}</Badge>)}</div></Card>}

      {/* Receita x Custo chart */}
      <Card>
        <div style={{fontWeight:700,marginBottom:12,fontSize:14}}>📈 Receita vs Custo no período</div>
        <ResponsiveContainer width="100%" height={160}>
          <LineChart data={chartData} margin={{top:4,right:4,left:-24,bottom:0}}>
            <XAxis dataKey="day" tick={{fill:G.muted,fontSize:9}} axisLine={false} tickLine={false} interval={Math.max(0,Math.floor(days/6)-1)}/>
            <YAxis tick={{fill:G.muted,fontSize:9}} axisLine={false} tickLine={false} tickFormatter={v=>`${(v/1000).toFixed(1)}k`}/>
            <Tooltip formatter={v=>R(v)} contentStyle={{background:G.surf,border:`1px solid ${G.bord}`,borderRadius:8,fontSize:12}}/>
            <Line type="monotone" dataKey="receita" name="Receita" stroke={G.pink} strokeWidth={2.5} dot={false} activeDot={{r:4}}/>
            <Line type="monotone" dataKey="custo" name="Custo" stroke={G.amber} strokeWidth={1.5} dot={false} strokeDasharray="4 2" activeDot={{r:3}}/>
          </LineChart>
        </ResponsiveContainer>
      </Card>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(210px,1fr))",gap:12}}>
        <Card>
          <div style={{fontWeight:700,marginBottom:10,fontSize:14}}>🏷️ Categorias</div>
          {pie.length===0?<div style={{color:G.muted,textAlign:"center",padding:18,fontSize:13}}>Sem vendas</div>:
          <><ResponsiveContainer width="100%" height={130}><PieChart><Pie data={pie} cx="50%" cy="50%" innerRadius={36} outerRadius={56} dataKey="value" paddingAngle={3}>{pie.map((_,i)=><Cell key={i} fill={PAL[i%PAL.length]}/>)}</Pie><Tooltip formatter={v=>R(v)} contentStyle={{background:G.surf,border:`1px solid ${G.bord}`,borderRadius:8,fontSize:12}}/></PieChart></ResponsiveContainer>
          <div style={{display:"flex",flexWrap:"wrap",gap:5,marginTop:6}}>{pie.map((p,i)=><Badge key={p.name} color={PAL[i%PAL.length]}>{p.name}</Badge>)}</div></>}
        </Card>
        <Card>
          <div style={{fontWeight:700,marginBottom:10,fontSize:14}}>💳 Por forma de pagamento</div>
          <div style={{display:"flex",flexDirection:"column",gap:9}}>
            {Object.entries(mMap).filter(([,v])=>v>0).map(([m,v])=>(
              <div key={m} style={{display:"flex",alignItems:"center",gap:9}}>
                <div style={{width:8,height:8,borderRadius:"50%",background:MC[m],flexShrink:0}}/>
                <span style={{flex:1,fontSize:13}}>{METHODS[m]}</span>
                <span style={{color:MC[m],fontWeight:700,fontSize:13}}>{R(v)}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <div style={{fontWeight:700,marginBottom:12,fontSize:14}}>⭐ Top clientes no período</div>
        {topC.filter(c=>c.n>0).length===0?<div style={{color:G.muted,fontSize:13}}>Sem vendas no período.</div>:
        topC.filter(c=>c.n>0).map((c,i)=>(
          <div key={c.id} style={{display:"flex",alignItems:"center",gap:10,marginBottom:i<topC.length-1?10:0}}>
            <div style={{width:32,height:32,borderRadius:"50%",flexShrink:0,background:`linear-gradient(135deg,${PAL[i]},${PAL[(i+3)%PAL.length]})`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:12,color:"#fff"}}>{INI(c.name)}</div>
            <div style={{flex:1}}><div style={{fontSize:13,fontWeight:600}}>{c.name}</div><div style={{fontSize:11,color:G.muted}}>{c.n} compra(s)</div></div>
            <span style={{color:G.pink,fontWeight:800,fontSize:14}}>{R(c.spent)}</span>
          </div>
        ))}
      </Card>
    </div>
  );
}

// ── Products ──────────────────────────────────────────────────
function Products({products,storeId,toast,onRefresh}){
  const [open,setOpen]=useState(false);const [edit,setEdit]=useState(null);const [q,setQ]=useState("");
  const empty={name:"",category:"",cost_price:"",sale_price:"",stock:"",description:"",photo_url:""};
  const [f,setF]=useState(empty);const [saving,setSaving]=useState(false);

  const openNew=()=>{setF(empty);setEdit(null);setOpen(true);};
  const openEdit=p=>{setF({name:p.name,category:p.category||"",cost_price:p.cost_price,sale_price:p.sale_price,stock:p.stock,description:p.description||"",photo_url:p.photo_url||""});setEdit(p);setOpen(true);};
  const save=async()=>{
    if(!f.name||!f.sale_price){toast("Nome e preço são obrigatórios","#f87171");return;}
    setSaving(true);
    const d={name:f.name,category:f.category||"Geral",cost_price:+f.cost_price||0,sale_price:+f.sale_price,stock:+f.stock||0,description:f.description||"",photo_url:f.photo_url||"",store_id:storeId,active:true};
    const {error}=edit?await sb.from("products").update(d).eq("id",edit.id):await sb.from("products").insert(d);
    if(error){toast("Erro: "+error.message,"#f87171");}else{toast(edit?"Produto atualizado!":"Produto cadastrado!");setOpen(false);}
    setSaving(false);
  };
  const del=async id=>{await sb.from("products").update({active:false}).eq("id",id);toast("Removido","#f87171");};

  const margin = f.sale_price&&f.cost_price ? (((+f.sale_price-+f.cost_price)/+f.sale_price)*100).toFixed(1) : null;
  const list=products.filter(p=>p.active&&(p.name.toLowerCase().includes(q.toLowerCase())||p.category?.toLowerCase().includes(q.toLowerCase())));
  const cats=[...new Set(products.filter(p=>p.active).map(p=>p.category))];

  return(
    <div style={{display:"flex",flexDirection:"column",gap:12}}>
      <div style={{display:"flex",gap:9}}><Inp placeholder="🔍 Buscar..." value={q} onChange={e=>setQ(e.target.value)} style={{flex:1}}/><Btn onClick={openNew} variant="pink">+ Produto</Btn></div>
      <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
        {["Todos",...cats].map(c=><button key={c} onClick={()=>setQ(c==="Todos"?"":c)} style={{padding:"4px 11px",borderRadius:20,border:"none",background:(c==="Todos"&&!q)||q===c?G.pink:"#ffffff0e",color:(c==="Todos"&&!q)||q===c?"#fff":G.muted,fontSize:12,cursor:"pointer",fontWeight:(c==="Todos"&&!q)||q===c?700:400}}>{c}</button>)}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(155px,1fr))",gap:11}}>
        {list.map(p=>{
          const mg=p.sale_price&&p.cost_price?(((p.sale_price-p.cost_price)/p.sale_price)*100).toFixed(0):null;
          return(
            <div key={p.id} style={{background:G.card,border:`1px solid ${G.bord}`,borderRadius:14,overflow:"hidden"}}>
              <div style={{width:"100%",height:100,background:G.bg,display:"flex",alignItems:"center",justifyContent:"center",overflow:"hidden"}}>
                {p.photo_url?<img src={p.photo_url} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}}/>:<span style={{fontSize:32}}>👗</span>}
              </div>
              <div style={{padding:"10px 12px"}}>
                <div style={{fontSize:13,fontWeight:700,marginBottom:3,lineHeight:1.3}}>{p.name}</div>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:4}}>
                  <Badge color={G.pink}>{p.category}</Badge>
                  <span style={{color:G.pink,fontWeight:800,fontSize:14}}>{R(p.sale_price)}</span>
                </div>
                <div style={{display:"flex",justifyContent:"space-between",marginTop:5,fontSize:11,color:G.muted}}>
                  <span>Custo: {R(p.cost_price)}</span>
                  {mg&&<span style={{color:G.green}}>Mg: {mg}%</span>}
                </div>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginTop:6}}>
                  <span style={{color:p.stock<=3?G.red:G.muted,fontSize:12}}>Est: {p.stock}</span>
                  <div style={{display:"flex",gap:5}}><Btn small variant="ghost" onClick={()=>openEdit(p)}>✏️</Btn><Btn small variant="danger" onClick={()=>del(p.id)}>✕</Btn></div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
      {open&&<Modal title={edit?"Editar Produto":"Novo Produto"} onClose={()=>setOpen(false)}>
        <div style={{display:"flex",flexDirection:"column",gap:11}}>
          <PhotoUpload value={f.photo_url} onChange={v=>setF({...f,photo_url:v})}/>
          <Inp label="Nome *" value={f.name} onChange={e=>setF({...f,name:e.target.value})} placeholder="Ex: Legging Power Preta P"/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Inp label="Categoria" value={f.category} onChange={e=>setF({...f,category:e.target.value})} placeholder="Legging, Top..."/>
            <Inp label="Estoque" value={f.stock} onChange={e=>setF({...f,stock:e.target.value})} type="number" min="0"/>
          </div>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Inp label="Preço de custo R$" value={f.cost_price} onChange={e=>setF({...f,cost_price:e.target.value})} type="number" min="0" step="0.01"/>
            <Inp label="Preço de venda R$ *" value={f.sale_price} onChange={e=>setF({...f,sale_price:e.target.value})} type="number" min="0" step="0.01"/>
          </div>
          {margin&&<div style={{background:`${G.green}12`,border:`1px solid ${G.green}30`,borderRadius:9,padding:"9px 13px",display:"flex",justifyContent:"space-between"}}><span style={{color:G.muted,fontSize:13}}>Margem de contribuição</span><span style={{color:G.green,fontWeight:700,fontSize:14}}>{margin}%</span></div>}
          <TA label="Descrição" value={f.description} onChange={e=>setF({...f,description:e.target.value})} placeholder="Tecido, corte, tamanho..."/>
          <div style={{display:"flex",gap:9,marginTop:4}}><Btn full onClick={save} variant="pink" disabled={saving}>{saving?<Spin/>:"Salvar"}</Btn><Btn full variant="ghost" onClick={()=>setOpen(false)}>Cancelar</Btn></div>
        </div>
      </Modal>}
    </div>
  );
}

// ── Costs ─────────────────────────────────────────────────────
function Costs({costs,customers,storeId,toast}){
  const [open,setOpen]=useState(false);const [edit,setEdit]=useState(null);
  const empty={name:"",amount:"",type:"fixed",recurrent:true,ref_month:"",customer_id:""};
  const [f,setF]=useState(empty);const [saving,setSaving]=useState(false);

  const openNew=()=>{setF({...empty,ref_month:TODAY().slice(0,7)});setEdit(null);setOpen(true);};
  const openEdit=c=>{setF({name:c.name,amount:c.amount,type:c.type,recurrent:c.recurrent,ref_month:c.ref_month||"",customer_id:c.customer_id||""});setEdit(c);setOpen(true);};
  const save=async()=>{
    if(!f.name||!f.amount){toast("Preencha nome e valor","#f87171");return;}
    setSaving(true);
    const d={name:f.name,amount:+f.amount,type:f.type,recurrent:f.recurrent,ref_month:f.ref_month||null,customer_id:f.customer_id||null,store_id:storeId};
    const{error}=edit?await sb.from("costs").update(d).eq("id",edit.id):await sb.from("costs").insert(d);
    if(error)toast("Erro: "+error.message,"#f87171");else{toast(edit?"Custo atualizado!":"Custo lançado!");setOpen(false);}
    setSaving(false);
  };
  const del=async id=>{await sb.from("costs").delete().eq("id",id);toast("Removido","#f87171");};

  const fixed=costs.filter(c=>c.type==="fixed");const variable=costs.filter(c=>c.type==="variable");
  const totalF=fixed.reduce((a,c)=>a+Number(c.amount),0);const totalV=variable.reduce((a,c)=>a+Number(c.amount),0);

  const CostRow=({c})=>{
    const cust=customers.find(x=>x.id===c.customer_id);
    return(
      <div style={{display:"flex",alignItems:"center",gap:9,background:"#ffffff06",borderRadius:9,padding:"9px 12px",marginBottom:6}}>
        <div style={{flex:1}}>
          <div style={{fontSize:13,fontWeight:600}}>{c.name}</div>
          <div style={{color:G.muted,fontSize:11,marginTop:2}}>
            {c.type==="fixed"?"Fixo":"Variável"}
            {c.ref_month?" · "+fmtMonth(c.ref_month+"-01"):""}
            {cust?" · "+cust.name:""}
          </div>
        </div>
        <span style={{color:G.amber,fontWeight:700,fontSize:14}}>{R(c.amount)}</span>
        <Btn small variant="ghost" onClick={()=>openEdit(c)}>✏️</Btn>
        <Btn small variant="danger" onClick={()=>del(c.id)}>✕</Btn>
      </div>
    );
  };

  return(
    <div style={{display:"flex",flexDirection:"column",gap:12}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <div><div style={{color:G.muted,fontSize:12}}>Total fixos: <span style={{color:G.amber,fontWeight:700}}>{R(totalF)}</span> · Variáveis: <span style={{color:G.violet,fontWeight:700}}>{R(totalV)}</span></div></div>
        <Btn onClick={openNew} variant="pink" small>+ Lançar custo</Btn>
      </div>

      <Card>
        <div style={{fontWeight:700,fontSize:14,marginBottom:10}}>🔒 Custos Fixos</div>
        {fixed.length===0?<div style={{color:G.muted,fontSize:13}}>Nenhum custo fixo lançado.</div>:fixed.map(c=><CostRow key={c.id} c={c}/>)}
      </Card>
      <Card>
        <div style={{fontWeight:700,fontSize:14,marginBottom:10}}>📦 Custos Variáveis / Entrega</div>
        {variable.length===0?<div style={{color:G.muted,fontSize:13}}>Nenhum custo variável lançado.</div>:variable.map(c=><CostRow key={c.id} c={c}/>)}
      </Card>

      {open&&<Modal title={edit?"Editar Custo":"Lançar Custo"} onClose={()=>setOpen(false)}>
        <div style={{display:"flex",flexDirection:"column",gap:11}}>
          <Inp label="Descrição *" value={f.name} onChange={e=>setF({...f,name:e.target.value})} placeholder="Ex: Aluguel, Taxa de entrega, Embalagem..."/>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
            <Inp label="Valor R$ *" value={f.amount} onChange={e=>setF({...f,amount:e.target.value})} type="number" min="0" step="0.01"/>
            <Sel label="Tipo" value={f.type} onChange={e=>setF({...f,type:e.target.value})}>
              <option value="fixed">Fixo (recorrente)</option>
              <option value="variable">Variável / Entrega</option>
            </Sel>
          </div>
          <Inp label="Mês de referência" type="month" value={f.ref_month} onChange={e=>setF({...f,ref_month:e.target.value})}/>
          <Sel label="Vincular a cliente (opcional — cobra só desta cliente)" value={f.customer_id} onChange={e=>setF({...f,customer_id:e.target.value})}>
            <option value="">Global (todas)</option>
            {customers.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
          </Sel>
          <div style={{background:`${G.amber}10`,border:`1px solid ${G.amber}25`,borderRadius:9,padding:"9px 13px",fontSize:12,color:G.muted}}>
            💡 Custos vinculados a uma cliente são descontados apenas nos relatórios dessa cliente. Custos globais são rateados no resultado geral.
          </div>
          <div style={{display:"flex",gap:9,marginTop:4}}><Btn full onClick={save} variant="pink" disabled={saving}>{saving?<Spin/>:"Salvar"}</Btn><Btn full variant="ghost" onClick={()=>setOpen(false)}>Cancelar</Btn></div>
        </div>
      </Modal>}
    </div>
  );
}

// ── New Sale ──────────────────────────────────────────────────
function NewSale({products,customers,storeId,toast,allSales,allInstallments}){
  const [cId,setCId]=useState("");const [date,setDate]=useState(TODAY());
  const [items,setItems]=useState([]);const [method,setMethod]=useState("pix");
  const [parc,setParc]=useState(1);const [diaVenc,setDiaVenc]=useState("10");
  const [notes,setNotes]=useState("");const [inclPend,setInclPend]=useState(false);
  const [saving,setSaving]=useState(false);

  const selC=customers.find(c=>c.id===cId);
  const pendInst=cId?allInstallments.filter(i=>i.customer_id===cId&&!i.paid):[];
  const pendTotal=pendInst.reduce((a,i)=>a+Number(i.amount),0);

  const addItem=pid=>{const p=products.find(x=>x.id===pid);if(!p)return;if(items.find(x=>x.pid===pid))setItems(items.map(x=>x.pid===pid?{...x,qty:x.qty+1}:x));else setItems([...items,{pid:pid,qty:1,sale_price:p.sale_price,cost_price:p.cost_price,name:p.name,category:p.category}]);};
  const rmItem=pid=>setItems(items.filter(x=>x.pid!==pid));
  const chgQty=(pid,q)=>q<1?rmItem(pid):setItems(items.map(x=>x.pid===pid?{...x,qty:q}:x));

  const sub=items.reduce((a,x)=>a+x.qty*x.sale_price,0);
  const cmv=items.reduce((a,x)=>a+x.qty*x.cost_price,0);
  const canParc=method==="credit"||method==="crediario";
  const effParc=canParc?parc:1;
  const total=inclPend?+(sub+pendTotal).toFixed(2):sub;
  const instVal=+(total/effParc).toFixed(2);

  const submit=async()=>{
    if(!items.length){toast("Adicione pelo menos um produto","#f87171");return;}
    setSaving(true);
    try{
      // 1. Create sale
      const{data:sale,error:sErr}=await sb.from("sales").insert({
        store_id:storeId,customer_id:cId||null,date,
        subtotal:sub,total_cost:cmv,total,method,installments:effParc,notes
      }).select().single();
      if(sErr)throw sErr;

      // 2. Insert items
      await sb.from("sale_items").insert(items.map(it=>({
        sale_id:sale.id,product_id:it.pid,product_name:it.name,
        category:it.category,quantity:it.qty,unit_price:it.sale_price,cost_price:it.cost_price
      })));

      // 3. Update stock
      for(const it of items){
        const p=products.find(x=>x.id===it.pid);
        if(p&&p.stock!==999)await sb.from("products").update({stock:Math.max(0,p.stock-it.qty)}).eq("id",it.pid);
      }

      // 4. Cancel pending installments if inclPend
      if(inclPend&&cId&&pendInst.length){
        await sb.from("installments").update({paid:true,paid_at:new Date().toISOString()}).in("id",pendInst.map(i=>i.id));
      }

      // 5. Create installments
      const insts=Array.from({length:effParc},(_,i)=>({
        sale_id:sale.id,store_id:storeId,customer_id:cId||null,
        number:i+1,amount:instVal,
        due_date:method==="crediario"?dueDateDay(date,i+1,diaVenc):addMonths(date,i+1),
        paid:effParc===1&&(method==="pix"||method==="debit")
      }));
      await sb.from("installments").insert(insts);

      toast("✅ Venda registrada!");
      setItems([]);setCId("");setMethod("pix");setParc(1);setInclPend(false);setNotes("");setDate(TODAY());
    }catch(e){toast("Erro: "+e.message,"#f87171");}
    setSaving(false);
  };

  return(
    <div style={{display:"flex",flexDirection:"column",gap:12}}>
      <Card>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:11}}>
          <Sel label="Cliente" value={cId} onChange={e=>{setCId(e.target.value);setInclPend(false);}}>
            <option value="">Avulso (sem cadastro)</option>
            {customers.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
          </Sel>
          <Inp label="Data da venda" type="date" value={date} onChange={e=>setDate(e.target.value)} hint="Aceita datas retroativas"/>
        </div>
        {selC&&pendTotal>0&&(
          <div style={{marginTop:10,background:`${G.amber}12`,border:`1px solid ${G.amber}30`,borderRadius:9,padding:"10px 13px",display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:8}}>
            <div><div style={{color:G.amber,fontWeight:700,fontSize:13}}>⚠️ Saldo em aberto</div><div style={{color:G.muted,fontSize:12}}>{R(pendTotal)} pendentes ({pendInst.length} parcelas)</div></div>
            <button onClick={()=>setInclPend(!inclPend)} style={{padding:"6px 12px",borderRadius:8,border:"none",fontWeight:700,fontSize:12,cursor:"pointer",background:inclPend?G.amber:"#ffffff10",color:inclPend?"#000":"#fff"}}>{inclPend?"✓ Incluído":"Incluir no parcelamento"}</button>
          </div>
        )}
      </Card>

      <Card>
        <Sel label="Adicionar produto" value="" onChange={e=>{if(e.target.value){addItem(e.target.value);e.target.value=""}}}>
          <option value="">Selecione um produto...</option>
          {products.filter(p=>p.active).map(p=><option key={p.id} value={p.id}>{p.name} — {R(p.sale_price)}{p.stock<=3?" ⚠️":""}</option>)}
        </Sel>
        {items.length>0&&<div style={{marginTop:11,display:"flex",flexDirection:"column",gap:7}}>{items.map(it=>(
          <div key={it.pid} style={{display:"flex",alignItems:"center",gap:8,background:"#ffffff07",borderRadius:9,padding:"7px 10px"}}>
            <span style={{flex:1,fontSize:13,fontWeight:600}}>{it.name}</span>
            <span style={{color:G.muted,fontSize:11}}>CMV: {R(it.cost_price)}</span>
            <button onClick={()=>chgQty(it.pid,it.qty-1)} style={QB}>−</button>
            <span style={{fontWeight:700,minWidth:20,textAlign:"center",fontSize:13}}>{it.qty}</span>
            <button onClick={()=>chgQty(it.pid,it.qty+1)} style={QB}>+</button>
            <span style={{color:G.pink,fontWeight:700,minWidth:60,textAlign:"right",fontSize:13}}>{R(it.qty*it.sale_price)}</span>
            <button onClick={()=>rmItem(it.pid)} style={{background:"none",border:"none",color:G.red,cursor:"pointer",fontSize:15}}>✕</button>
          </div>
        ))}</div>}
      </Card>

      <Card>
        <div style={{fontWeight:700,marginBottom:10,fontSize:13}}>💳 Pagamento</div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:7,marginBottom:12}}>
          {[["pix","PIX 💚",G.green],["debit","Débito 🟡",G.amber],["credit","Crédito 💜",G.violet],["crediario","Crediário 🩷",G.rose]].map(([m,l,col])=>(
            <button key={m} onClick={()=>{setMethod(m);if(m!=="credit"&&m!=="crediario")setParc(1);}} style={{padding:"9px 0",borderRadius:9,border:`1.5px solid ${method===m?col:G.bord}`,background:method===m?col+"22":"transparent",color:method===m?col:G.muted,fontWeight:method===m?700:400,fontSize:13,cursor:"pointer"}}>{l}</button>
          ))}
        </div>
        {canParc&&<>
          <span style={{color:G.muted,fontSize:11,textTransform:"uppercase",letterSpacing:.8,display:"block",marginBottom:7}}>Parcelas</span>
          <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:method==="crediario"?11:0}}>
            {[1,2,3,4,5,6,8,10,12].map(n=><button key={n} onClick={()=>setParc(n)} style={{padding:"6px 11px",borderRadius:8,border:"none",fontWeight:parc===n?700:400,fontSize:13,cursor:"pointer",background:parc===n?(method==="crediario"?G.rose:G.violet):"#ffffff0e",color:parc===n?"#fff":G.muted}}>{n}x</button>)}
          </div>
          {method==="crediario"&&parc>1&&<Sel label="Dia do vencimento" value={diaVenc} onChange={e=>setDiaVenc(e.target.value)} style={{marginTop:8}}>
            {["5","10","15","20","25","30"].map(d=><option key={d} value={d}>Todo dia {d}</option>)}
          </Sel>}
        </>}
      </Card>

      <Inp label="Observações (opcional)" value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Notas sobre a venda..."/>

      <Card style={{background:G.bg}}>
        <div style={{display:"flex",justifyContent:"space-between",color:G.muted,fontSize:13,marginBottom:5}}><span>Subtotal</span><span style={{color:G.text}}>{R(sub)}</span></div>
        <div style={{display:"flex",justifyContent:"space-between",color:G.muted,fontSize:13,marginBottom:5}}><span>CMV (custo)</span><span style={{color:G.amber}}>{R(cmv)}</span></div>
        {inclPend&&pendTotal>0&&<div style={{display:"flex",justifyContent:"space-between",color:G.muted,fontSize:13,marginBottom:5}}><span>Saldo anterior</span><span style={{color:G.rose}}>{R(pendTotal)}</span></div>}
        <Divider my={8}/>
        <div style={{display:"flex",justifyContent:"space-between",fontWeight:900,fontSize:20,marginBottom:canParc&&parc>1?8:0}}><span>Total</span><span style={{color:G.pink}}>{R(total)}</span></div>
        {canParc&&parc>1&&<div style={{textAlign:"center",background:`${method==="crediario"?G.rose:G.violet}14`,border:`1px solid ${method==="crediario"?G.rose:G.violet}30`,borderRadius:9,padding:"8px 12px",marginBottom:6}}><span style={{color:method==="crediario"?G.rose:G.violet,fontWeight:800,fontSize:16}}>{parc}x de {R(instVal)}</span></div>}
        <Btn full onClick={submit} disabled={saving||!items.length} variant="pink" style={{marginTop:10,padding:"12px 0",fontSize:15}}>{saving?<Spin/>:"Registrar Venda"}</Btn>
      </Card>
    </div>
  );
}
const QB={width:26,height:26,borderRadius:6,border:`1px solid ${G.bord2}`,background:"#ffffff0e",color:"#fff",cursor:"pointer",fontSize:14,fontWeight:700,lineHeight:1,flexShrink:0};

// ── Sales List ────────────────────────────────────────────────
function SalesList({sales,customers,installments,storeId,toast}){
  const [df,setDf]=useState("");const [dt,setDt]=useState("");
  const [cFil,setCFil]=useState("");const [mFil,setMFil]=useState("");const [exp,setExp]=useState(null);

  const list=sales.filter(s=>{
    if(df&&s.date<df)return false;if(dt&&s.date>dt)return false;
    if(cFil&&s.customer_id!==cFil)return false;if(mFil&&s.method!==mFil)return false;
    return true;
  }).sort((a,b)=>b.date.localeCompare(a.date)||b.created_at?.localeCompare(a.created_at||"")||0);

  const payInst=async(instId)=>{await sb.from("installments").update({paid:true,paid_at:new Date().toISOString()}).eq("id",instId);toast("Parcela paga! ✓");};

  return(
    <div style={{display:"flex",flexDirection:"column",gap:12}}>
      <Card style={{padding:"12px 14px"}}>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9,marginBottom:9}}>
          <Inp label="De" type="date" value={df} onChange={e=>setDf(e.target.value)}/><Inp label="Até" type="date" value={dt} onChange={e=>setDt(e.target.value)}/>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:9}}>
          <Sel label="Cliente" value={cFil} onChange={e=>setCFil(e.target.value)}><option value="">Todos</option>{customers.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</Sel>
          <Sel label="Pagamento" value={mFil} onChange={e=>setMFil(e.target.value)}><option value="">Todos</option>{Object.entries(METHODS).map(([k,v])=><option key={k} value={k}>{v}</option>)}</Sel>
        </div>
      </Card>
      {list.length===0&&<Card><div style={{color:G.muted,textAlign:"center",padding:28}}>Nenhuma venda encontrada.</div></Card>}
      {list.map(s=>{
        const cust=customers.find(c=>c.id===s.customer_id);
        const sInst=installments.filter(i=>i.sale_id===s.id);
        const pend=sInst.filter(i=>!i.paid);
        const hasOverdue=pend.some(i=>i.due_date<TODAY());
        const expanded=exp===s.id;
        return(
          <Card key={s.id} style={{borderColor:hasOverdue?G.red+"44":G.bord}}>
            <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:8,cursor:"pointer"}} onClick={()=>setExp(expanded?null:s.id)}>
              <div>
                <div style={{fontWeight:700,fontSize:14}}>{fmtD(s.date)} — {cust?.name||"Avulso"}</div>
                <div style={{display:"flex",gap:5,marginTop:5,flexWrap:"wrap"}}>
                  <Badge color={MC[s.method]}>{METHODS[s.method]}</Badge>
                  {s.installments>1&&<Badge color={G.violet}>{s.installments}x de {R(s.total/s.installments)}</Badge>}
                  {hasOverdue&&<Badge color={G.red}>Vencida</Badge>}
                </div>
              </div>
              <div style={{textAlign:"right"}}>
                <div style={{color:G.pink,fontWeight:800,fontSize:17}}>{R(s.total)}</div>
                <div style={{color:G.muted,fontSize:12}}>{pend.length>0?`${pend.length} pendente(s)`:"✓ Quitado"}</div>
                <div style={{color:G.muted,fontSize:11,marginTop:2}}>{expanded?"▲ Ocultar":"▼ Detalhes"}</div>
              </div>
            </div>
            {expanded&&(
              <div style={{marginTop:12}}>
                <Divider/>
                <div style={{display:"flex",flexWrap:"wrap",gap:5,marginBottom:10}}>
                  {s.items.map((it,i)=><Badge key={i} color="#ffffff25">{it.quantity}x {it.product_name}</Badge>)}
                </div>
                <div style={{display:"flex",justifyContent:"space-between",color:G.muted,fontSize:12,marginBottom:8}}>
                  <span>CMV: {R(s.total_cost)}</span>
                  <span>Margem: {R(Number(s.total)-Number(s.total_cost))} ({pct(Number(s.total)-Number(s.total_cost),Number(s.total))})</span>
                </div>
                <div style={{display:"flex",flexDirection:"column",gap:7}}>
                  {sInst.map((inst,i)=>(
                    <InstRow key={i} inst={inst} custName={cust?.name} custPhone={cust?.phone} onPay={payInst} storeName="Fitness Store" showWA={!!cust?.phone}/>
                  ))}
                </div>
                {s.notes&&<div style={{marginTop:10,color:G.muted,fontSize:12}}>📝 {s.notes}</div>}
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}

// ── Due Dates ─────────────────────────────────────────────────
function DueDates({installments,customers,storeName,toast}){
  const [filter,setFilter]=useState("all");const [cFil,setCFil]=useState("");
  const allPend=installments.filter(i=>!i.paid).sort((a,b)=>a.due_date.localeCompare(b.due_date));
  const weekEnd=new Date();weekEnd.setDate(weekEnd.getDate()+7);const we=weekEnd.toISOString().slice(0,10);
  const filtered=allPend.filter(i=>{
    if(cFil&&i.customer_id!==cFil)return false;
    if(filter==="overdue")return i.due_date<TODAY();
    if(filter==="today")return i.due_date===TODAY();
    if(filter==="week")return i.due_date>=TODAY()&&i.due_date<=we;
    if(filter==="crediario")return i.method==="crediario";
    return true;
  });
  const totalPend=filtered.reduce((a,i)=>a+Number(i.amount),0);
  const byCust={};filtered.forEach(i=>{const k=i.customer_id||"avulso";if(!byCust[k])byCust[k]={id:k,items:[]};byCust[k].items.push(i);});
  const payInst=async id=>{await sb.from("installments").update({paid:true,paid_at:new Date().toISOString()}).eq("id",id);toast("Parcela paga! ✓");};

  return(
    <div style={{display:"flex",flexDirection:"column",gap:13}}>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(115px,1fr))",gap:9}}>
        {[["Pendentes",allPend.length,G.violet],["Vencidas",allPend.filter(i=>i.due_date<TODAY()).length,G.red],["Hoje",allPend.filter(i=>i.due_date===TODAY()).length,G.amber],["Total",R(allPend.reduce((a,i)=>a+Number(i.amount),0)),G.pink]].map(([l,v,col])=>(
          <Card key={l} style={{borderLeft:`3px solid ${col}`,padding:"11px 13px"}}><div style={{color:G.muted,fontSize:10,textTransform:"uppercase",letterSpacing:.7}}>{l}</div><div style={{color:col,fontSize:18,fontWeight:900,marginTop:4}}>{v}</div></Card>
        ))}
      </div>
      <Card style={{padding:"12px 14px"}}>
        <div style={{display:"flex",gap:5,flexWrap:"wrap",marginBottom:10}}>
          {[["all","Todas"],["overdue","Vencidas"],["today","Hoje"],["week","7 dias"]].map(([k,l])=>(
            <button key={k} onClick={()=>setFilter(k)} style={{padding:"5px 12px",borderRadius:20,border:"none",fontSize:12,fontWeight:filter===k?700:400,background:filter===k?G.rose:"#ffffff0e",color:filter===k?"#fff":G.muted,cursor:"pointer"}}>{l}</button>
          ))}
        </div>
        <Sel value={cFil} onChange={e=>setCFil(e.target.value)}>
          <option value="">Todas as clientes</option>
          {customers.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}
        </Sel>
      </Card>
      {filtered.length>0&&<div style={{background:`${G.pink}10`,border:`1px solid ${G.pink}22`,borderRadius:10,padding:"10px 14px",display:"flex",justifyContent:"space-between"}}><span style={{color:G.muted,fontSize:13}}>Total filtrado</span><span style={{color:G.pink,fontWeight:800,fontSize:16}}>{R(totalPend)}</span></div>}
      {Object.values(byCust).map(({id,items})=>{
        const cust=customers.find(c=>c.id===id);
        const total=items.reduce((a,i)=>a+Number(i.amount),0);
        const hasOverdue=items.some(i=>i.due_date<TODAY());
        return(
          <Card key={id} style={{borderColor:hasOverdue?G.red+"44":G.bord}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12,flexWrap:"wrap",gap:8}}>
              <div style={{display:"flex",gap:10,alignItems:"center"}}>
                <div style={{width:38,height:38,borderRadius:"50%",flexShrink:0,background:`linear-gradient(135deg,${G.pink},${G.violet})`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:13,color:"#fff"}}>{cust?INI(cust.name):"?"}</div>
                <div><div style={{fontWeight:700,fontSize:14}}>{cust?.name||"Avulso"}</div>{cust?.phone&&<div style={{color:G.muted,fontSize:12}}>📞 {cust.phone}</div>}</div>
              </div>
              <div style={{textAlign:"right"}}><div style={{color:G.pink,fontWeight:800,fontSize:15}}>{R(total)}</div><div style={{color:G.muted,fontSize:12}}>{items.length} parcela(s)</div></div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:7}}>
              {items.map((inst,i)=><InstRow key={i} inst={inst} custName={cust?.name} custPhone={cust?.phone} onPay={payInst} storeName={storeName}/>)}
            </div>
            {cust?.phone&&items.filter(i=>i.due_date<TODAY()).length>0&&(
              <div style={{marginTop:10,paddingTop:10,borderTop:`1px solid ${G.bord}`}}>
                <button onClick={()=>{items.filter(i=>i.due_date<TODAY()).forEach(i=>window.open(waLink(cust.phone,cust.name,i.number,i.amount,i.due_date,storeName,true),"_blank"));toast("WhatsApp aberto!");}} style={{display:"flex",alignItems:"center",gap:6,background:"#25D36618",border:"1px solid #25D36640",color:"#25D366",borderRadius:8,padding:"6px 13px",fontSize:12,cursor:"pointer",fontWeight:700}}>📱 Cobrar todas vencidas via WhatsApp</button>
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}

// ── Customer Profile ──────────────────────────────────────────
function CustomerProfile({cust,sales,installments,customers,storeName,toast}){
  const cSales=sales.filter(s=>s.customer_id===cust.id);
  const cInst=installments.filter(i=>i.customer_id===cust.id);
  const paid=cInst.filter(i=>i.paid);const pend=cInst.filter(i=>!i.paid);
  const overdue=pend.filter(i=>i.due_date<TODAY());const upcoming=pend.filter(i=>i.due_date>=TODAY());
  const totalSpent=cSales.reduce((a,s)=>a+Number(s.total),0);
  const totalPaid=paid.reduce((a,i)=>a+Number(i.amount),0);
  const totalPend=pend.reduce((a,i)=>a+Number(i.amount),0);
  const [tab,setTab]=useState("compras");
  const payInst=async id=>{await sb.from("installments").update({paid:true,paid_at:new Date().toISOString()}).eq("id",id);toast("Pago! ✓");};

  return(
    <div style={{display:"flex",flexDirection:"column",gap:14}}>
      {/* Header */}
      <Card style={{background:`linear-gradient(135deg,${G.pink}18,${G.violet}18)`,borderColor:G.pink+"33"}}>
        <div style={{display:"flex",gap:14,alignItems:"center",flexWrap:"wrap"}}>
          <div style={{width:56,height:56,borderRadius:"50%",flexShrink:0,background:`linear-gradient(135deg,${G.pink},${G.violet})`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:900,fontSize:20,color:"#fff"}}>{INI(cust.name)}</div>
          <div style={{flex:1}}>
            <div style={{fontWeight:800,fontSize:18}}>{cust.name}</div>
            {cust.phone&&<div style={{color:G.muted,fontSize:13}}>📞 {cust.phone}</div>}
            {cust.email&&<div style={{color:G.muted,fontSize:13}}>✉️ {cust.email}</div>}
            {cust.notes&&<div style={{color:G.violet,fontSize:12,marginTop:4}}>📝 {cust.notes}</div>}
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(110px,1fr))",gap:9,marginTop:14}}>
          {[["Total gasto",R(totalSpent),G.pink],["Pago",R(totalPaid),G.green],["A vencer",R(upcoming.reduce((a,i)=>a+Number(i.amount),0)),G.violet],["Vencidos",R(overdue.reduce((a,i)=>a+Number(i.amount),0)),G.red]].map(([l,v,col])=>(
            <div key={l} style={{background:"#ffffff08",borderRadius:10,padding:"10px 12px"}}>
              <div style={{color:G.muted,fontSize:10,textTransform:"uppercase",letterSpacing:.7}}>{l}</div>
              <div style={{color:col,fontWeight:800,fontSize:15,marginTop:3}}>{v}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* Tabs */}
      <div style={{display:"flex",gap:4}}>
        {[["compras","🛍️ Compras"],["pagos","✅ Pagos"],["vencidos","🔴 Vencidos"],["avencer","⏳ A vencer"]].map(([k,l])=>(
          <button key={k} onClick={()=>setTab(k)} style={{flex:1,padding:"8px 4px",borderRadius:9,border:"none",background:tab===k?G.pink+"22":"transparent",color:tab===k?G.pink:G.muted,fontWeight:tab===k?700:400,fontSize:12,cursor:"pointer",borderBottom:tab===k?`2px solid ${G.pink}`:"2px solid transparent"}}>{l}</button>
        ))}
      </div>

      {/* Compras */}
      {tab==="compras"&&<div style={{display:"flex",flexDirection:"column",gap:9}}>
        {cSales.length===0&&<Card><div style={{color:G.muted,textAlign:"center",padding:24}}>Nenhuma compra registrada.</div></Card>}
        {cSales.sort((a,b)=>b.date.localeCompare(a.date)).map(s=>{
          const si=installments.filter(i=>i.sale_id===s.id);const pendS=si.filter(i=>!i.paid);
          return(<Card key={s.id}><div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:8}}>
            <div><div style={{fontWeight:700,fontSize:14}}>{fmtD(s.date)}</div><div style={{display:"flex",gap:5,marginTop:4,flexWrap:"wrap"}}><Badge color={MC[s.method]}>{METHODS[s.method]}</Badge>{s.installments>1&&<Badge color={G.violet}>{s.installments}x</Badge>}{pendS.length===0&&<Badge color={G.green}>Quitado</Badge>}</div></div>
            <div style={{textAlign:"right"}}><div style={{color:G.pink,fontWeight:800,fontSize:16}}>{R(s.total)}</div>{pendS.length>0&&<div style={{color:G.amber,fontSize:12}}>{pendS.length} pendente(s)</div>}</div>
          </div><div style={{display:"flex",flexWrap:"wrap",gap:5,marginTop:8}}>{s.items.map((it,i)=><Badge key={i} color="#ffffff20">{it.quantity}x {it.product_name}</Badge>)}</div></Card>);
        })}
      </div>}

      {/* Pagos */}
      {tab==="pagos"&&<div style={{display:"flex",flexDirection:"column",gap:7}}>
        {paid.length===0&&<Card><div style={{color:G.muted,textAlign:"center",padding:24}}>Nenhum pagamento registrado.</div></Card>}
        {paid.sort((a,b)=>b.paid_at?.localeCompare(a.paid_at||"")).map((i,idx)=><InstRow key={idx} inst={i} showWA={false}/>)}
      </div>}

      {/* Vencidos */}
      {tab==="vencidos"&&<div style={{display:"flex",flexDirection:"column",gap:7}}>
        {overdue.length===0&&<Card style={{borderColor:G.green+"44"}}><div style={{color:G.green,textAlign:"center",padding:24}}>✅ Nenhuma parcela vencida!</div></Card>}
        {overdue.sort((a,b)=>a.due_date.localeCompare(b.due_date)).map((i,idx)=><InstRow key={idx} inst={i} custName={cust.name} custPhone={cust.phone} onPay={payInst} storeName={storeName}/>)}
        {overdue.length>0&&cust.phone&&<button onClick={()=>{overdue.forEach(i=>window.open(waLink(cust.phone,cust.name,i.number,i.amount,i.due_date,storeName,true),"_blank"));toast("WhatsApp aberto!");}} style={{display:"flex",alignItems:"center",gap:6,background:"#25D36618",border:"1px solid #25D36640",color:"#25D366",borderRadius:8,padding:"8px 14px",fontSize:13,cursor:"pointer",fontWeight:700}}>📱 Cobrar todas via WhatsApp</button>}
      </div>}

      {/* A vencer */}
      {tab==="avencer"&&<div style={{display:"flex",flexDirection:"column",gap:7}}>
        {upcoming.length===0&&<Card><div style={{color:G.muted,textAlign:"center",padding:24}}>Nenhuma parcela a vencer.</div></Card>}
        {upcoming.sort((a,b)=>a.due_date.localeCompare(b.due_date)).map((i,idx)=><InstRow key={idx} inst={i} custName={cust.name} custPhone={cust.phone} onPay={payInst} storeName={storeName}/>)}
      </div>}
    </div>
  );
}

// ── Customers ─────────────────────────────────────────────────
function Customers({customers,sales,installments,storeId,storeName,toast}){
  const [open,setOpen]=useState(false);const [selected,setSelected]=useState(null);const [edit,setEdit]=useState(null);
  const [f,setF]=useState({name:"",phone:"",email:"",notes:""});const [q,setQ]=useState("");const [saving,setSaving]=useState(false);
  const openNew=()=>{setF({name:"",phone:"",email:"",notes:""});setEdit(null);setOpen(true);};
  const openEdit=c=>{setF({name:c.name,phone:c.phone||"",email:c.email||"",notes:c.notes||""});setEdit(c);setOpen(true);};
  const save=async()=>{
    if(!f.name){toast("Nome é obrigatório","#f87171");return;}
    setSaving(true);
    const d={name:f.name,phone:f.phone,email:f.email,notes:f.notes,store_id:storeId};
    const{error}=edit?await sb.from("customers").update(d).eq("id",edit.id):await sb.from("customers").insert(d);
    if(error)toast("Erro: "+error.message,"#f87171");else{toast(edit?"Cliente atualizada!":"Cliente cadastrada!");setOpen(false);}
    setSaving(false);
  };
  const del=async id=>{await sb.from("customers").delete().eq("id",id);toast("Removida","#f87171");};
  const list=customers.filter(c=>c.name.toLowerCase().includes(q.toLowerCase())||c.phone?.includes(q));

  if(selected){
    return(
      <div>
        <button onClick={()=>setSelected(null)} style={{display:"flex",alignItems:"center",gap:6,background:"transparent",border:"none",color:G.muted,cursor:"pointer",fontSize:13,marginBottom:14}}>← Voltar</button>
        <CustomerProfile cust={selected} sales={sales} installments={installments} customers={customers} storeName={storeName} toast={toast}/>
      </div>
    );
  }

  return(
    <div style={{display:"flex",flexDirection:"column",gap:12}}>
      <div style={{display:"flex",gap:9}}><Inp placeholder="🔍 Buscar cliente..." value={q} onChange={e=>setQ(e.target.value)} style={{flex:1}}/><Btn onClick={openNew} variant="pink">+ Cliente</Btn></div>
      {list.map(c=>{
        const cs=sales.filter(s=>s.customer_id===c.id);const spent=cs.reduce((a,s)=>a+Number(s.total),0);
        const pendInst=installments.filter(i=>i.customer_id===c.id&&!i.paid);const pendVal=pendInst.reduce((a,i)=>a+Number(i.amount),0);
        const hasOverdue=pendInst.some(i=>i.due_date<TODAY());
        return(
          <Card key={c.id} onClick={()=>setSelected(c)} style={{cursor:"pointer",borderColor:hasOverdue?G.red+"44":G.bord}}>
            <div style={{display:"flex",justifyContent:"space-between",flexWrap:"wrap",gap:8}}>
              <div style={{display:"flex",gap:11,alignItems:"center"}}>
                <div style={{width:44,height:44,borderRadius:"50%",flexShrink:0,background:`linear-gradient(135deg,${G.pink},${G.violet})`,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,fontSize:15,color:"#fff"}}>{INI(c.name)}</div>
                <div><div style={{fontWeight:700,fontSize:15}}>{c.name}</div>{c.phone&&<div style={{color:G.muted,fontSize:12}}>📞 {c.phone}</div>}{c.email&&<div style={{color:G.muted,fontSize:12}}>✉️ {c.email}</div>}</div>
              </div>
              <div style={{textAlign:"right"}}>
                <div style={{color:G.pink,fontWeight:800,fontSize:16}}>{R(spent)}</div>
                <div style={{color:G.muted,fontSize:12}}>{cs.length} compras</div>
                {pendVal>0&&<div style={{marginTop:3}}><Badge color={hasOverdue?G.red:G.amber}>A receber: {R(pendVal)}</Badge></div>}
              </div>
            </div>
            {c.notes&&<div style={{marginTop:7,color:G.muted,fontSize:12}}>📝 {c.notes}</div>}
            <div style={{marginTop:10,display:"flex",gap:7}} onClick={e=>e.stopPropagation()}>
              <Btn small variant="ghost" onClick={()=>openEdit(c)}>✏️ Editar</Btn>
              <Btn small variant="danger" onClick={()=>del(c.id)}>✕</Btn>
              <Btn small variant="pink" onClick={()=>setSelected(c)}>Ver perfil →</Btn>
            </div>
          </Card>
        );
      })}
      {open&&<Modal title={edit?"Editar Cliente":"Nova Cliente"} onClose={()=>setOpen(false)}>
        <div style={{display:"flex",flexDirection:"column",gap:11}}>
          <Inp label="Nome *" value={f.name} onChange={e=>setF({...f,name:e.target.value})} placeholder="Nome completo"/>
          <Inp label="Telefone (com DDI: 5511999990000)" value={f.phone} onChange={e=>setF({...f,phone:e.target.value})} placeholder="5511999990000"/>
          <Inp label="E-mail" value={f.email} onChange={e=>setF({...f,email:e.target.value})} placeholder="email@exemplo.com"/>
          <TA label="Observações" value={f.notes} onChange={e=>setF({...f,notes:e.target.value})} placeholder="Tamanho preferido, gostos, notas..."/>
          <div style={{display:"flex",gap:9,marginTop:4}}><Btn full onClick={save} variant="pink" disabled={saving}>{saving?<Spin/>:"Salvar"}</Btn><Btn full variant="ghost" onClick={()=>setOpen(false)}>Cancelar</Btn></div>
        </div>
      </Modal>}
    </div>
  );
}

// ── Settings ──────────────────────────────────────────────────
function Settings({storeName,storeId,toast,onSignOut}){
  const [name,setName]=useState(storeName);
  const save=async()=>{await sb.from("stores").update({name}).eq("id",storeId);toast("Salvo! ✓");};
  return(
    <div style={{display:"flex",flexDirection:"column",gap:13}}>
      <Card>
        <div style={{fontWeight:700,fontSize:15,marginBottom:12}}>⚙️ Configurações da loja</div>
        <div style={{display:"flex",gap:9}}>
          <Inp label="Nome da loja" value={name} onChange={e=>setName(e.target.value)} style={{flex:1}} placeholder="Ex: FitStore Moda Fitness"/>
          <Btn onClick={save} variant="pink" style={{alignSelf:"flex-end"}}>Salvar</Btn>
        </div>
      </Card>
      <Card>
        <div style={{fontWeight:700,fontSize:14,marginBottom:10}}>📱 WhatsApp — como funciona</div>
        {["O botão 📱 abre o WhatsApp Business com mensagem pronta personalizada.","Para parcelas vencidas: mensagem de cobrança amigável.","Para parcelas a vencer: lembrete preventivo.","O telefone deve ter DDI: ex. 5511999990000","Funciona com WhatsApp Business e pessoal."].map((t,i)=>(
          <div key={i} style={{display:"flex",gap:9,alignItems:"flex-start",marginBottom:7}}><span style={{color:G.pink,fontWeight:700,flexShrink:0}}>✓</span><span style={{color:G.muted,fontSize:13}}>{t}</span></div>
        ))}
      </Card>
      <Card style={{background:`${G.green}08`,borderColor:`${G.green}30`}}>
        <div style={{fontWeight:700,fontSize:14,marginBottom:8,color:G.green}}>🔄 Realtime Supabase</div>
        <div style={{color:G.muted,fontSize:13}}>Todas as alterações feitas por qualquer usuário (vendas, pagamentos, estoque) são refletidas instantaneamente em todos os dispositivos conectados via WebSocket.</div>
      </Card>
      <Btn variant="danger" onClick={onSignOut} style={{alignSelf:"flex-start"}}>Sair da conta</Btn>
    </div>
  );
}

// ── Main App ──────────────────────────────────────────────────
const TABS=[{l:"Dashboard",i:"📊"},{l:"Nova Venda",i:"🛒"},{l:"Vendas",i:"🧾"},{l:"Vencimentos",i:"📅"},{l:"Clientes",i:"👤"},{l:"Produtos",i:"👗"},{l:"Custos",i:"💸"},{l:"Config",i:"⚙️"}];

export default function Home(){
  const [user,    setUser]    = useState(null);
  const [storeId, setStoreId] = useState(null);
  const [storeName,setSName]  = useState("Fitness CRM");
  const [loading, setLoading] = useState(true);
  const [rtOk,    setRtOk]    = useState(false);
  const [tab,     setTab]     = useState(0);
  const [tn,      setTn]      = useState({msg:"",col:G.green});

  // Data
  const [products,     setProducts]     = useState([]);
  const [customers,    setCustomers]    = useState([]);
  const [sales,        setSales]        = useState([]);
  const [saleItems,    setSaleItems]    = useState([]);
  const [installments, setInstallments] = useState([]);
  const [costs,        setCosts]        = useState([]);

  const toast = useCallback((msg,col=G.violet)=>{setTn({msg,col});setTimeout(()=>setTn({msg:"",col:G.violet}),2800);},[]);

  // Auth init
  useEffect(()=>{
    sb.auth.getSession().then(({data:{session}})=>{
      if(session?.user) initStore(session.user);
      else setLoading(false);
    });
    const{data:{subscription}}=sb.auth.onAuthStateChange((_,session)=>{
      if(session?.user)initStore(session.user);else{setUser(null);setStoreId(null);setLoading(false);}
    });
    return()=>subscription.unsubscribe();
  },[]);

  const initStore = async(u)=>{
    setUser(u);
    const{data}=await sb.from("store_users").select("store_id,stores(name)").eq("user_id",u.id).single();
    if(data){setStoreId(data.store_id);setSName(data.stores?.name||"Fitness CRM");}
    setLoading(false);
  };

  // Load data when storeId ready
  useEffect(()=>{
    if(!storeId)return;
    loadAll();
    setupRealtime();
  },[storeId]);

  const loadAll = async()=>{
    const[p,c,s,si,i,co]=await Promise.all([
      sb.from("products").select("*").eq("store_id",storeId).eq("active",true).order("name"),
      sb.from("customers").select("*").eq("store_id",storeId).order("name"),
      sb.from("sales").select("*").eq("store_id",storeId).order("date",{ascending:false}),
      sb.from("sale_items").select("*"),
      sb.from("installments").select("*").eq("store_id",storeId).order("due_date"),
      sb.from("costs").select("*").eq("store_id",storeId).order("created_at",{ascending:false}),
    ]);
    if(p.data)setProducts(p.data);
    if(c.data)setCustomers(c.data);
    if(s.data){
      const salesWithItems=s.data.map(sale=>({...sale,items:si.data?.filter(x=>x.sale_id===sale.id)||[]}));
      setSales(salesWithItems);
    }
    if(i.data)setInstallments(i.data);
    if(co.data)setCosts(co.data);
  };

  const setupRealtime = ()=>{
    const channel = sb.channel(`store-${storeId}`)
      .on("postgres_changes",{event:"*",schema:"public",table:"products",filter:`store_id=eq.${storeId}`},()=>loadAll())
      .on("postgres_changes",{event:"*",schema:"public",table:"customers",filter:`store_id=eq.${storeId}`},()=>loadAll())
      .on("postgres_changes",{event:"*",schema:"public",table:"sales",filter:`store_id=eq.${storeId}`},()=>loadAll())
      .on("postgres_changes",{event:"*",schema:"public",table:"sale_items"},()=>loadAll())
      .on("postgres_changes",{event:"*",schema:"public",table:"installments",filter:`store_id=eq.${storeId}`},()=>loadAll())
      .on("postgres_changes",{event:"*",schema:"public",table:"costs",filter:`store_id=eq.${storeId}`},()=>loadAll())
      .on("postgres_changes",{event:"*",schema:"public",table:"stores"},()=>loadAll())
      .subscribe(status=>{setRtOk(status==="SUBSCRIBED");});
    return()=>sb.removeChannel(channel);
  };

  const handleSignOut=async()=>{await sb.auth.signOut();setUser(null);setStoreId(null);setSales([]);setProducts([]);setCustomers([]);setInstallments([]);setCosts([]);};

  if(loading)return(
    <div style={{minHeight:"100vh",background:G.bg,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"system-ui,sans-serif"}}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
      <div style={{textAlign:"center"}}><div style={{fontSize:40,marginBottom:12}}>👗</div><div style={{color:G.pink,fontWeight:700}}>Carregando...</div></div>
    </div>
  );

  if(!user)return(<><style>{`@keyframes spin{to{transform:rotate(360deg)}}*{box-sizing:border-box}`}</style><AuthScreen onAuth={u=>{initStore(u);}}/></>);

  const panels=[
    <Dashboard sales={sales} products={products} customers={customers} costs={costs} installments={installments}/>,
    <NewSale products={products} customers={customers} storeId={storeId} toast={toast} allSales={sales} allInstallments={installments}/>,
    <SalesList sales={sales} customers={customers} installments={installments} storeId={storeId} toast={toast}/>,
    <DueDates installments={installments} customers={customers} storeName={storeName} toast={toast}/>,
    <Customers customers={customers} sales={sales} installments={installments} storeId={storeId} storeName={storeName} toast={toast}/>,
    <Products products={products} storeId={storeId} toast={toast}/>,
    <Costs costs={costs} customers={customers} storeId={storeId} toast={toast}/>,
    <Settings storeName={storeName} storeId={storeId} toast={toast} onSignOut={handleSignOut}/>,
  ];

  return(
    <div style={{minHeight:"100vh",background:G.bg,fontFamily:"system-ui,'Segoe UI',sans-serif",color:G.text}}>
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}*{box-sizing:border-box}::-webkit-scrollbar{width:4px;height:4px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:${G.bord2};border-radius:4px}`}</style>
      {/* Header */}
      <div style={{background:"#0b0b1799",backdropFilter:"blur(14px)",borderBottom:`1px solid ${G.bord}`,padding:"10px 16px",display:"flex",alignItems:"center",gap:12,position:"sticky",top:0,zIndex:300}}>
        <div style={{width:32,height:32,borderRadius:8,flexShrink:0,background:`linear-gradient(135deg,${G.pink},${G.violet})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16}}>👗</div>
        <div style={{flex:1}}>
          <div style={{fontWeight:900,fontSize:14,background:`linear-gradient(90deg,${G.pink},${G.violet})`,WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent"}}>{storeName}</div>
        </div>
        <RTBadge connected={rtOk}/>
        <div style={{color:G.muted,fontSize:11,maxWidth:100,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user.email}</div>
      </div>
      {/* Nav */}
      <div style={{display:"flex",overflowX:"auto",gap:1,padding:"7px 10px",borderBottom:`1px solid ${G.bord}`,background:G.bg,scrollbarWidth:"none"}}>
        {TABS.map((t,i)=>(
          <button key={i} onClick={()=>setTab(i)} style={{flexShrink:0,display:"flex",alignItems:"center",gap:4,padding:"6px 10px",borderRadius:8,border:"none",background:tab===i?`${G.pink}20`:"transparent",color:tab===i?G.pink:G.muted,fontWeight:tab===i?700:400,fontSize:12,cursor:"pointer",borderBottom:tab===i?`2px solid ${G.pink}`:"2px solid transparent",whiteSpace:"nowrap"}}>
            <span>{t.i}</span><span>{t.l}</span>
          </button>
        ))}
      </div>
      {/* Content */}
      <div style={{padding:"14px 14px 60px",maxWidth:740,margin:"0 auto"}}>
        {panels[tab]}
      </div>
      <Toast msg={tn.msg} color={tn.col}/>
    </div>
  );
}
